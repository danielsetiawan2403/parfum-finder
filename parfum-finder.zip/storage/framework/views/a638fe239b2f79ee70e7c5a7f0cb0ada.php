<?php $__env->startSection('title', 'Data Parfum'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1 class="page-title">Data Parfum</h1>
        <p class="page-sub">Tambah, ubah, atau hapus parfum yang tampil di situs.</p>
    </div>

    <div class="toolbar">
        <form action="<?php echo e(route('admin.perfumes.index')); ?>" method="GET" class="search" role="search">
            <label for="q" class="sr-only">Cari nama parfum</label>
            <input id="q" type="search" name="q" value="<?php echo e($q); ?>" placeholder="Cari nama parfum...">

            <label for="kategori" class="sr-only">Kategori</label>
            <select id="kategori" name="kategori" style="width: auto;">
                <option value="">Semua kategori</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category); ?>" <?php if($kategori === $category): echo 'selected'; endif; ?>><?php echo e($category); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit" class="btn btn-ghost">Cari</button>
            <?php if($q !== '' || $kategori): ?>
                <a href="<?php echo e(route('admin.perfumes.index')); ?>" class="btn btn-ghost">Reset</a>
            <?php endif; ?>
        </form>

        <a href="<?php echo e(route('admin.perfumes.create')); ?>" class="btn btn-primary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
            Tambah Parfum
        </a>
    </div>

    <section class="panel">
        <?php if($perfumes->isEmpty()): ?>
            <div class="empty">
                <?php if($q !== '' || $kategori): ?>
                    <strong>Tidak ada parfum yang cocok</strong>
                    Coba kata kunci atau kategori lain.
                <?php else: ?>
                    <strong>Belum ada parfum</strong>
                    Tambahkan parfum pertama untuk mengisi katalog.
                    <br><a href="<?php echo e(route('admin.perfumes.create')); ?>" class="btn btn-primary">Tambah Parfum</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="col-no">No</th>
                            <th>Parfum</th>
                            <th>Aroma</th>
                            <th>Kategori</th>
                            <th>Harga</th>
                            <th class="col-act">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $perfumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="col-no"><?php echo e($perfumes->firstItem() + $loop->index); ?></td>

                                <td>
                                    <div class="perfume-cell">
                                        <div class="thumb" aria-hidden="true">
                                            <?php echo e(mb_strtoupper(mb_substr($perfume->name, 0, 1))); ?>

                                            <?php if($perfume->image): ?>
                                                <img src="<?php echo e(asset($perfume->image)); ?>" alt="" loading="lazy" onerror="this.remove()">
                                            <?php endif; ?>
                                        </div>
                                        <span class="strong"><?php echo e($perfume->name); ?></span>
                                    </div>
                                </td>

                                <td data-label="Aroma">
                                    <?php if($perfume->top_notes || $perfume->middle_notes || $perfume->base_notes): ?>
                                        <dl class="notes">
                                            <?php $__currentLoopData = ['top_notes' => 'Top', 'middle_notes' => 'Middle', 'base_notes' => 'Base']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($perfume->$field): ?>
                                                    <div><dt><?php echo e($label); ?></dt><dd><?php echo e($perfume->$field); ?></dd></div>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </dl>
                                    <?php else: ?>
                                        <span class="muted">Belum diisi</span>
                                    <?php endif; ?>
                                </td>

                                <td data-label="Kategori"><?php echo e($perfume->category); ?></td>
                                <td data-label="Harga" style="white-space: nowrap;">Rp <?php echo e(number_format($perfume->price, 0, ',', '.')); ?></td>

                                <td class="col-act">
                                    <div class="cell-actions">
                                        <a href="<?php echo e(route('admin.perfumes.edit', $perfume)); ?>" class="btn btn-edit">Edit</a>

                                        <form action="<?php echo e(route('admin.perfumes.destroy', $perfume)); ?>" method="POST"
                                              data-confirm="Parfum &quot;<?php echo e($perfume->name); ?>&quot; dan semua ulasannya akan dihapus permanen."
                                              data-confirm-title="Hapus parfum?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">Hapus</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php echo e($perfumes->links('admin.partials.pagination')); ?>

        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/admin/perfumes/index.blade.php ENDPATH**/ ?>
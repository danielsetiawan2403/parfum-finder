<?php
    // User yang sedang login (null jika tamu)
    $authUser     = auth()->user();
    // Admin juga dianggap premium oleh isPremium()
    $isPremium    = $authUser?->isPremium() ?? false;
    $isAdmin      = $authUser?->role === 'admin';
    // Tanggal berakhir langganan (null jika admin atau tidak punya langganan)
    $premiumUntil = $authUser?->activeSubscription()?->ends_at;
    // Di halaman Premium (pilih paket, pembayaran, status) navbar hanya menampilkan Logout.
    $premiumFlow  = request()->routeIs('premium', 'premium.*');
?>

    <header class="bg-pf-red">
        <div class="container-fluid px-3 px-sm-4 py-2 d-flex flex-wrap align-items-center justify-content-between gap-2">
            
            <a href="<?php echo e(auth()->check() ? route('perfumes.index') : url('/')); ?>" class="text-white fw-bold text-decoration-none">Parfum Finder</a>

            <div class="d-flex flex-wrap align-items-center gap-2">

                
                <?php if(isset($categories)): ?>
                    <form action="<?php echo e(route('perfumes.index')); ?>" method="GET" class="d-flex align-items-center gap-1">
                        <label for="nav-q" class="visually-hidden">Cari parfum</label>
                        <input id="nav-q" name="q" type="search" value="<?php echo e(request('q')); ?>" placeholder="Search parfum..."
                               class="form-control form-control-sm pf-xs" style="width: 9rem;">

                        <label for="nav-kategori" class="visually-hidden">Kategori</label>
                        <select id="nav-kategori" name="kategori" class="form-select form-select-sm pf-xs" style="width: auto;">
                            <option value="">Semua Kategori</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category); ?>" <?php if(request('kategori') === $category): echo 'selected'; endif; ?>><?php echo e($category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <button type="submit" class="btn btn-dark btn-sm pf-xs">Go</button>
                    </form>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    
                    <?php if($isAdmin): ?>
                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-light btn-sm rounded-pill pf-xs fw-semibold">Panel Admin</a>
                    <?php endif; ?>

                    <?php if($premiumFlow): ?>
                        
                    <?php elseif($isAdmin): ?>
                        
                    <?php elseif($isPremium): ?>
                        
                        <a href="<?php echo e(route('chat.index')); ?>" class="btn btn-pf-gray btn-sm rounded-pill pf-xs fw-semibold">💬 Chat</a>

                        
                        <?php if($premiumUntil): ?>
                            <a href="<?php echo e(route('premium')); ?>" class="btn btn-light btn-sm rounded-pill pf-xs fw-semibold">
                                👑 Premium s/d <?php echo e($premiumUntil->locale('id')->translatedFormat('j M Y')); ?>

                            </a>
                        <?php endif; ?>
                    <?php else: ?>
                        
                        <a href="<?php echo e(route('premium')); ?>" class="btn btn-pf btn-sm rounded-pill pf-xs fw-semibold">Upgrade Premium</a>
                    <?php endif; ?>

                    
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="m-0">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-dark btn-sm rounded-pill pf-xs fw-semibold">Logout</button>
                    </form>
                <?php else: ?>
                    
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-sm text-white fw-semibold">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </header><?php /**PATH D:\laragon\www\parfum-finder\resources\views/partials/navbar.blade.php ENDPATH**/ ?>
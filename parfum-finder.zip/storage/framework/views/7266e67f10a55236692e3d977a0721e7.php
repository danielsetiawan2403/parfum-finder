

<?php $__env->startSection('title', 'Chat Konsultasi - Parfum Finder'); ?>

<?php $__env->startSection('content'); ?>
    <section class="px-3 py-4">
        <div class="container" style="max-width: 40rem;">

            <div class="bg-pf-card rounded-3 p-3 p-md-4">
                <h1 class="fs-6 fw-bold mb-3">💬 Chat Konsultasi Premium</h1>

                
                <div id="chat-box" class="pf-chat-box d-flex flex-column gap-2 mb-3">
                    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $mine = $message->sender === 'user'; ?>
                        <div class="d-flex <?php echo e($mine ? 'justify-content-end' : 'justify-content-start'); ?>">
                            <div class="pf-bubble rounded-3 px-3 py-2 <?php echo e($mine ? 'bg-pf-red' : 'bg-secondary'); ?>">
                                <div class="small"><?php echo e($message->body); ?></div>
                                <div class="text-white-50 text-end" style="font-size: .65rem;">
                                    <?php echo e($mine ? 'Kamu' : 'Ahli'); ?> &middot; <?php echo e($message->created_at->locale('id')->translatedFormat('j M, H:i')); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="pf-xs text-white-50 m-0">Belum ada pesan. Tulis pertanyaanmu seputar parfum di bawah ini.</p>
                    <?php endif; ?>
                </div>

                
                <form action="<?php echo e(route('chat.store')); ?>" method="POST" novalidate>
                    <?php echo csrf_field(); ?>
                    <label for="body" class="visually-hidden">Pesan</label>
                    <textarea id="body" name="body" rows="3" maxlength="1000" placeholder="Tulis pesan..."
                              class="form-control pf-xs <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo e(old('body')); ?></textarea>
                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="pf-error"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <button type="submit" class="btn btn-pf-red btn-sm rounded-pill px-4 mt-3 fw-semibold">Kirim</button>
                </form>
            </div>

            <a href="<?php echo e(route('perfumes.index')); ?>" class="btn btn-pf-slate btn-sm rounded-pill pf-xs fw-semibold mt-3">&larr; Kembali ke Dashboard</a>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Gulir otomatis ke pesan terbaru.
        var box = document.getElementById('chat-box');
        if (box) { box.scrollTop = box.scrollHeight; }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/chat/index.blade.php ENDPATH**/ ?>
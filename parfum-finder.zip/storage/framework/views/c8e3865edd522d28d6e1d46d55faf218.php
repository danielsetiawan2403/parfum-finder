

<?php $__env->startSection('title', 'Dashboard - Parfum Finder'); ?>

<?php $__env->startSection('content'); ?>
    
    <section class="bg-black text-center px-3 py-5">
        <?php if(auth()->guard()->check()): ?>
            <h1 class="fw-bold fs-2">Hi, <?php echo e(auth()->user()->username ?? auth()->user()->name); ?> 👋</h1>
        <?php else: ?>
            <h1 class="fw-bold fs-2">Explore Parfum</h1>
        <?php endif; ?>

        <p class="pf-xs text-white-50 mt-2 mb-0">Temukan parfum favoritmu sesuai kategori dan aroma yang diinginkan.</p>

        <?php if($q !== '' || $kategori): ?>
            <p class="pf-xs text-white-50 mt-3 mb-0">
                <?php echo e($perfumes->count()); ?> hasil
                <?php if($q !== ''): ?> untuk "<?php echo e($q); ?>" <?php endif; ?>
                <?php if($kategori): ?> di kategori <?php echo e($kategori); ?> <?php endif; ?>
                &middot;
                <a href="<?php echo e(route('perfumes.index')); ?>" class="text-white">Reset</a>
            </p>
        <?php endif; ?>
    </section>

    
    <section class="px-3 py-4">
        <div class="container" style="max-width: 64rem;">
            <?php if($perfumes->isEmpty()): ?>
                <p class="small text-white-50 text-center py-5">Parfum tidak ditemukan. Coba kata kunci atau kategori lain.</p>
            <?php else: ?>
                <div class="row row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-5 g-3">
                    <?php $__currentLoopData = $perfumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <a href="<?php echo e(route('perfumes.show', $perfume)); ?>"
                               class="pf-card d-block h-100 bg-pf-card rounded-3 overflow-hidden text-white text-decoration-none">
                                <div class="pf-img">
                                    <img src="<?php echo e(asset($perfume->image)); ?>" alt="<?php echo e($perfume->name); ?>"
                                         loading="lazy" onerror="this.style.display='none'">
                                </div>
                                <p class="pf-xs fw-bold text-center lh-sm m-0 px-2 py-2 d-flex align-items-center justify-content-center" style="min-height: 3rem;"><?php echo e($perfume->name); ?></p>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/dashboard.blade.php ENDPATH**/ ?>
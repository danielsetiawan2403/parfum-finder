<?php $__env->startSection('title', 'Chat ' . $user->name); ?>

<?php $__env->startSection('content'); ?>
    <section class="panel chat-card chat-room">
        <div class="chat-head">
            <div class="chat-who">
                <strong><?php echo e($user->name); ?></strong>
                <span><?php echo e($user->username); ?></span>
            </div>
        </div>

        <div class="thread thread--room" data-thread>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="msg <?php echo e($message->sender === 'user' ? 'msg--user' : 'msg--admin'); ?>">
                    <div class="bubble"><?php echo e($message->body); ?></div>
                    <time datetime="<?php echo e($message->created_at->toIso8601String()); ?>">
                        <?php echo e($message->sender === 'user' ? $user->name : 'Kamu (admin)'); ?>,
                        <?php echo e($message->created_at->locale('id')->translatedFormat('j M, H:i')); ?>

                    </time>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <form action="<?php echo e(route('admin.chats.reply', $user)); ?>" method="POST" class="reply">
            <?php echo csrf_field(); ?>
            <label for="reply-body" class="sr-only">Balasan untuk <?php echo e($user->name); ?></label>
            <textarea id="reply-body" name="body" rows="2" maxlength="1000"
                      placeholder="Tulis balasan admin..." required
                      class="<?php echo e($errors->has('body') ? 'is-invalid' : ''); ?>"><?php echo e(old('body')); ?></textarea>
            <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="field-error"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="reply-actions">
                <button type="submit" class="btn btn-primary">Kirim balasan</button>
                <a href="<?php echo e(route('admin.chats.index')); ?>" class="btn btn-ghost">&larr; Kembali</a>
            </div>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/admin/chats/show.blade.php ENDPATH**/ ?>
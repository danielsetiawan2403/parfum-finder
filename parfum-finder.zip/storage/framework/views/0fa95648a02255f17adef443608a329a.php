<?php $__env->startSection('title', 'Member Premium'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1 class="page-title">Member Premium</h1>
        <p class="page-sub">Riwayat langganan Premium: tanggal mulai, tanggal selesai, dan harga.</p>
    </div>

    <div class="menu-grid" style="margin-bottom: 24px;">
        <div class="menu-card">
            <h2>Member Aktif</h2>
            <p>Langganan yang masih berjalan</p>
            <span class="stat"><?php echo e($totalAktif); ?> user</span>
        </div>
        <div class="menu-card">
            <h2>Total Pendapatan</h2>
            <p>Dari semua langganan yang sudah dibayar</p>
            <span class="stat">Rp <?php echo e(number_format($totalPendapatan, 0, ',', '.')); ?></span>
        </div>
    </div>

    <div class="toolbar">
        <form action="<?php echo e(route('admin.premium.index')); ?>" method="GET" class="search" role="search">
            <label for="q" class="sr-only">Cari member</label>
            <input id="q" type="search" name="q" value="<?php echo e($q); ?>" placeholder="Cari nama, email, username, atau invoice...">

            <label for="status" class="sr-only">Status</label>
            <select id="status" name="status">
                <option value="">Semua status</option>
                <option value="aktif" <?php if($status === 'aktif'): echo 'selected'; endif; ?>>Aktif</option>
                <option value="berakhir" <?php if($status === 'berakhir'): echo 'selected'; endif; ?>>Berakhir</option>
            </select>

            <button type="submit" class="btn btn-ghost">Cari</button>
            <?php if($q !== '' || $status !== ''): ?>
                <a href="<?php echo e(route('admin.premium.index')); ?>" class="btn btn-ghost">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <section class="panel">
        <?php if($subscriptions->isEmpty()): ?>
            <div class="empty">
                <strong>Belum ada member premium</strong>
                Data akan muncul setelah ada user yang menyelesaikan pembayaran.
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="col-no">No</th>
                            <th>User</th>
                            <th>Invoice</th>
                            <th>Paket</th>
                            <th>Harga</th>
                            <th>Mulai</th>
                            <th>Selesai</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $aktif = $s->ends_at && $s->ends_at->isFuture(); ?>
                            <tr>
                                <td class="col-no"><?php echo e($subscriptions->firstItem() + $loop->index); ?></td>
                                <td data-label="User">
                                    <span class="strong"><?php echo e($s->user->name ?? '(user dihapus)'); ?></span><br>
                                    <small style="color: var(--muted); overflow-wrap: anywhere;"><?php echo e($s->user->email ?? ''); ?></small>
                                </td>
                                <td data-label="Invoice"><?php echo e($s->invoice); ?></td>
                                <td data-label="Paket"><?php echo e($s->label); ?></td>
                                <td data-label="Harga">Rp <?php echo e(number_format($s->price, 0, ',', '.')); ?></td>
                                <td data-label="Mulai"><?php echo e($s->starts_at?->locale('id')->translatedFormat('j M Y')); ?></td>
                                <td data-label="Selesai"><?php echo e($s->ends_at?->locale('id')->translatedFormat('j M Y')); ?></td>
                                <td data-label="Status">
                                    <?php if($aktif): ?>
                                        <span class="badge badge--ok">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge badge--free">Berakhir</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php echo e($subscriptions->links('admin.partials.pagination')); ?>

        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/admin/premium/index.blade.php ENDPATH**/ ?>
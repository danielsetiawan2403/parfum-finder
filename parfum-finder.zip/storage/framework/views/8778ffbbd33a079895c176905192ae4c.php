<?php $__env->startSection('title', 'Data Ulasan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1 class="page-title">Data Ulasan</h1>
        <p class="page-sub">Pantau ulasan dari member Premium dan hapus ulasan yang melanggar.</p>
    </div>

    
    <div class="menu-grid" style="margin-bottom: 24px;">
        <div class="menu-card">
            <h2>Total Ulasan</h2>
            <p><?php echo e($isFiltered ? 'Sesuai filter yang dipilih' : 'Dari semua parfum'); ?></p>
            <span class="stat"><?php echo e($total); ?> ulasan</span>
        </div>
        <div class="menu-card">
            <h2>Rata-rata Rating</h2>
            <p><?php echo e($isFiltered ? 'Sesuai filter yang dipilih' : 'Dari semua parfum'); ?></p>
            <span class="stat"><?php echo e($average !== null ? number_format($average, 1, ',', '.') . ' dari 5' : 'Belum ada'); ?></span>
        </div>
        <div class="menu-card">
            <h2>Rating Rendah</h2>
            <p>Ulasan dengan 1 sampai 2 bintang</p>
            <span class="stat <?php echo e($lowCount > 0 ? 'stat--alert' : ''); ?>"><?php echo e($lowCount); ?> ulasan</span>
        </div>
    </div>

    <div class="toolbar">
        <form action="<?php echo e(route('admin.reviews.index')); ?>" method="GET" class="search" role="search">
            <label for="q" class="sr-only">Cari ulasan</label>
            <input id="q" type="search" name="q" value="<?php echo e($q); ?>" placeholder="Cari isi ulasan atau nama user...">

            <label for="parfum" class="sr-only">Parfum</label>
            <select id="parfum" name="parfum" onchange="this.form.submit()">
                <option value="">Semua parfum</option>
                <?php $__currentLoopData = $perfumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($perfume->id); ?>" <?php if($perfumeId === $perfume->id): echo 'selected'; endif; ?>><?php echo e($perfume->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label for="rating" class="sr-only">Rating</label>
            <select id="rating" name="rating" onchange="this.form.submit()">
                <option value="">Semua rating</option>
                <?php for($i = 5; $i >= 1; $i--): ?>
                    <option value="<?php echo e($i); ?>" <?php if($rating === $i): echo 'selected'; endif; ?>><?php echo e($i); ?> bintang</option>
                <?php endfor; ?>
            </select>

            <label for="urut" class="sr-only">Urutkan</label>
            <select id="urut" name="urut" onchange="this.form.submit()">
                <option value="terbaru" <?php if($sort === 'terbaru'): echo 'selected'; endif; ?>>Terbaru</option>
                <option value="terlama" <?php if($sort === 'terlama'): echo 'selected'; endif; ?>>Terlama</option>
                <option value="rating-terendah" <?php if($sort === 'rating-terendah'): echo 'selected'; endif; ?>>Rating terendah</option>
                <option value="rating-tertinggi" <?php if($sort === 'rating-tertinggi'): echo 'selected'; endif; ?>>Rating tertinggi</option>
            </select>

            <button type="submit" class="btn btn-ghost">Cari</button>
            <?php if($isCustom): ?>
                <a href="<?php echo e(route('admin.reviews.index')); ?>" class="btn btn-ghost">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <section class="panel">
        <?php if($reviews->isEmpty()): ?>
            <div class="empty">
                <?php if($isFiltered): ?>
                    <strong>Tidak ada ulasan yang cocok</strong>
                    Coba ubah filter atau kata kunci.
                <?php else: ?>
                    <strong>Belum ada ulasan</strong>
                    Ulasan dari member Premium akan muncul di sini.
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="review-list">
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $name = $review->user->name ?? '(user dihapus)'; ?>
                    <article class="review <?php echo e($review->rating <= 2 ? 'is-low' : ''); ?>">
                        <span class="review-avatar" aria-hidden="true"><?php echo e(mb_strtoupper(mb_substr($name, 0, 1))); ?></span>

                        <div class="review-main">
                            <div class="review-head">
                                <strong><?php echo e($name); ?></strong>
                                <span class="review-meta">
                                    <?php echo e($review->user->username ?? ''); ?> &middot; pada
                                    <span class="review-perfume"><?php echo e($review->perfume->name ?? '(parfum dihapus)'); ?></span>
                                </span>
                                <time class="review-time" datetime="<?php echo e($review->created_at->toIso8601String()); ?>">
                                    <?php echo e($review->created_at->locale('id')->translatedFormat('j M Y, H:i')); ?>

                                </time>
                            </div>

                            <div class="review-stars" role="img" aria-label="Rating <?php echo e($review->rating); ?> dari 5">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <span class="<?php echo e($i <= $review->rating ? 'on' : ''); ?>">★</span>
                                <?php endfor; ?>
                            </div>

                            <p class="review-body"><?php echo e($review->body); ?></p>
                        </div>

                        <form action="<?php echo e(route('admin.reviews.destroy', $review)); ?>" method="POST" class="review-act"
                              data-confirm="Ulasan dari &quot;<?php echo e($name); ?>&quot; akan dihapus permanen. Akun user tidak ikut terhapus."
                              data-confirm-title="Hapus ulasan?">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php echo e($reviews->links('admin.partials.pagination')); ?>

        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/admin/reviews/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Edit Parfum'); ?>
<?php $__env->startSection('page-class', 'page--narrow'); ?>

<?php $__env->startSection('content'); ?>
    <div class="form-head">
        <a href="<?php echo e(route('admin.perfumes.index')); ?>" class="btn btn-ghost">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>
            Kembali
        </a>
        <h1 class="page-title">Edit Parfum</h1>
    </div>

    <section class="panel">
        <div class="panel-body">
            <?php echo $__env->make('admin.perfumes._form', [
                'action'      => route('admin.perfumes.update', $perfume),
                'method'      => 'PUT',
                'submitLabel' => 'Simpan perubahan',
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/admin/perfumes/edit.blade.php ENDPATH**/ ?>
<?php
    $selectedCategory = old('category', $perfume->category);
?>

<form action="<?php echo e($action); ?>" method="POST" enctype="multipart/form-data" novalidate>
    <?php echo csrf_field(); ?>
    <?php if($method !== 'POST'): ?>
        <?php echo method_field($method); ?>
    <?php endif; ?>

    <div class="form-grid">

        <div class="field">
            <label for="name">Nama parfum</label>
            <input type="text" id="name" name="name" value="<?php echo e(old('name', $perfume->name)); ?>" maxlength="255"
                   placeholder="Contoh: Versace Eros" required class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-row">
            <div class="field">
                <label for="category">Kategori</label>
                <select id="category" name="category" required class="<?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="" disabled <?php if(! $selectedCategory): echo 'selected'; endif; ?>>Pilih kategori</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category); ?>" <?php if($selectedCategory === $category): echo 'selected'; endif; ?>><?php echo e($category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="field">
                <label for="price">Harga (Rp)</label>
                <input type="number" id="price" name="price" value="<?php echo e(old('price', $perfume->price)); ?>"
                       min="0" step="1" inputmode="numeric" placeholder="1500000" required
                       class="<?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <p class="hint" id="priceHint">Tulis angka saja, tanpa titik atau koma.</p>
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <fieldset class="form-section">
            <legend>Aroma (notes)</legend>

            <div class="field">
                <label for="top_notes">Top notes</label>
                <textarea id="top_notes" name="top_notes" rows="2" maxlength="1000"
                          placeholder="Aroma awal. Contoh: Mint, Green Apple, Lemon"
                          class="<?php $__errorArgs = ['top_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('top_notes', $perfume->top_notes)); ?></textarea>
                <?php $__errorArgs = ['top_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="field">
                <label for="middle_notes">Middle notes</label>
                <textarea id="middle_notes" name="middle_notes" rows="2" maxlength="1000"
                          placeholder="Aroma inti. Contoh: Tonka Bean, Ambroxan, Geranium"
                          class="<?php $__errorArgs = ['middle_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('middle_notes', $perfume->middle_notes)); ?></textarea>
                <?php $__errorArgs = ['middle_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="field">
                <label for="base_notes">Base notes</label>
                <textarea id="base_notes" name="base_notes" rows="2" maxlength="1000"
                          placeholder="Aroma dasar. Contoh: Vanilla, Cedarwood, Vetiver"
                          class="<?php $__errorArgs = ['base_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('base_notes', $perfume->base_notes)); ?></textarea>
                <?php $__errorArgs = ['base_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </fieldset>

        <div class="field">
            <label for="description">Deskripsi</label>
            <textarea id="description" name="description" rows="4" maxlength="3000"
                      placeholder="Kesan aroma, karakter, dan cocok dipakai untuk acara apa."
                      class="<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('description', $perfume->description)); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="field">
            <span class="field-label">Foto parfum</span>

            <div class="photo">
                <div class="photo-preview" id="photoPreview">
                    <span>Belum ada foto</span>
                    <?php if($perfume->image): ?>
                        <img src="<?php echo e(asset($perfume->image)); ?>" alt="Foto <?php echo e($perfume->name); ?>" id="photoImg" onerror="this.remove()">
                    <?php endif; ?>
                </div>

                <div class="photo-file">
                    <input type="file" id="image" name="image" accept="image/png,image/jpeg,image/webp">
                    <label for="image" class="btn btn-ghost"><?php echo e($perfume->exists ? 'Ganti foto' : 'Pilih foto'); ?></label>
                    <span class="photo-name" id="photoName">Belum ada file dipilih</span>
                    <p class="hint">JPG, PNG, atau WEBP, maksimal 2 MB.<?php if($perfume->exists): ?> Kosongkan jika tidak ingin mengganti foto.<?php endif; ?></p>
                </div>
            </div>
            <p class="field-error" id="photoError" hidden></p>
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-actions">
        <a href="<?php echo e(route('admin.perfumes.index')); ?>" class="btn btn-ghost">Batal</a>
        <button type="submit" class="btn btn-primary"><?php echo e($submitLabel); ?></button>
    </div>
</form>

<?php $__env->startPush('scripts'); ?>
    <script>
        (function () {
            // Pratinjau foto yang dipilih
            var input = document.getElementById('image');
            var preview = document.getElementById('photoPreview');
            var nameEl = document.getElementById('photoName');
            var errEl = document.getElementById('photoError');
            var MAX = 2 * 1024 * 1024;

            input.addEventListener('change', function () {
                var file = input.files && input.files[0];
                errEl.hidden = true;

                if (!file) { nameEl.textContent = 'Belum ada file dipilih'; return; }

                if (file.size > MAX) {
                    input.value = '';
                    nameEl.textContent = 'Belum ada file dipilih';
                    errEl.textContent = 'Ukuran foto maksimal 2 MB.';
                    errEl.hidden = false;
                    return;
                }

                nameEl.textContent = file.name;

                var img = document.getElementById('photoImg');
                if (!img) {
                    img = document.createElement('img');
                    img.id = 'photoImg';
                    img.alt = 'Pratinjau foto';
                    preview.appendChild(img);
                }
                img.src = URL.createObjectURL(file);
            });

            // Harga dalam format rupiah di bawah kolom
            var price = document.getElementById('price');
            var hint = document.getElementById('priceHint');

            function showPrice() {
                var n = parseInt(price.value, 10);
                hint.textContent = isNaN(n)
                    ? 'Tulis angka saja, tanpa titik atau koma.'
                    : 'Tampil sebagai Rp ' + n.toLocaleString('id-ID');
            }
            price.addEventListener('input', showPrice);
            showPrice();
        })();
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\laragon\www\parfum-finder\resources\views/admin/perfumes/_form.blade.php ENDPATH**/ ?>
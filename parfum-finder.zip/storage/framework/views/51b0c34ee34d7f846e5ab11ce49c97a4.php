

<?php $__env->startSection('title', 'Premium Membership - Parfum Finder'); ?>

<?php $__env->startSection('content'); ?>
    <section class="px-3 py-5">
        <div class="container" style="max-width: 43rem;">

            <?php if(session('warning')): ?>
                <div role="alert" class="alert alert-warning small"><?php echo e(session('warning')); ?></div>
            <?php endif; ?>

            <div class="bg-white text-dark rounded-4 shadow p-4 p-md-5">
                <h1 class="fs-3 fw-bold text-center">👑 Premium Membership</h1>
                <p class="text-center text-secondary small">Buka akses penuh ke konsultasi ahli dan rekomendasi parfum terbaik.</p>

                <div class="d-flex flex-wrap justify-content-center gap-2 my-3">
                    <span class="badge rounded-pill text-bg-light border fw-normal py-2 px-3">✓ Konsultasi Ahli</span>
                    <span class="badge rounded-pill text-bg-light border fw-normal py-2 px-3">✓ Rekomendasi Eksklusif</span>
                    <span class="badge rounded-pill text-bg-light border fw-normal py-2 px-3">✓ Tanpa Iklan</span>
                </div>

                <form action="<?php echo e(route('premium.checkout')); ?>" method="POST" novalidate>
                    <?php echo csrf_field(); ?>

                    <?php $__errorArgs = ['plan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div role="alert" class="alert alert-danger py-2 small"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="row g-3">
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 col-md-4">
                                <label for="plan-<?php echo e($key); ?>" class="pf-plan d-block h-100 text-center border rounded-3 p-3">
                                    <input type="radio" name="plan" id="plan-<?php echo e($key); ?>" value="<?php echo e($key); ?>"
                                           class="form-check-input d-block mx-auto mb-2" <?php if(old('plan') === $key): echo 'checked'; endif; ?> required>
                                    <span class="d-block fw-bold"><?php echo e($plan['label']); ?></span>
                                    <span class="d-block fw-bold text-danger small">Rp <?php echo e(number_format($plan['price'], 0, ',', '.')); ?></span>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <button type="submit" class="btn btn-pf-red w-100 fw-bold text-uppercase py-2 mt-4">Upgrade Sekarang</button>
                </form>
            </div>

            <p class="text-center mt-3 mb-0">
                <a href="<?php echo e(route('perfumes.index')); ?>" class="text-white-50 small text-decoration-none">&larr; Kembali ke Dashboard</a>
            </p>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/premium/index.blade.php ENDPATH**/ ?>
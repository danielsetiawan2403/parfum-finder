

<?php $__env->startSection('title', 'Premium Membership - Parfum Finder'); ?>

<?php $__env->startSection('content'); ?>
    <section class="px-3 py-5">
        <div class="container" style="max-width: 32rem;">

            <?php if(session('success')): ?>
                <div role="alert" class="alert alert-success small"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="bg-white text-dark rounded-4 shadow p-4">
                <h1 class="fs-3 fw-bold text-center">👑 Premium Membership</h1>
                <p class="text-center text-secondary small">Nikmati semua fitur eksklusif kamu.</p>

                <div class="text-center rounded-3 p-3 border" style="background: #fff3f3; border-color: #f5c2c7 !important;">
                    <div class="fw-bold text-danger">Status: Aktif</div>

                    <?php if($subscription): ?>
                        <div class="small">Berlaku hingga:</div>
                        <div class="fw-bold"><?php echo e($subscription->ends_at->locale('id')->translatedFormat('j M Y')); ?></div>
                        <div class="text-secondary mt-1" style="font-size: .7rem;"><?php echo e($subscription->label); ?> &middot; <?php echo e($subscription->invoice); ?></div>
                    <?php else: ?>
                        <div class="small">Akses tanpa batas waktu (akun admin).</div>
                    <?php endif; ?>
                </div>

                <div class="d-grid mt-3">
                    <a href="<?php echo e(route('chat.index')); ?>" class="btn btn-pf-red rounded-pill fw-semibold">💬 Buka Chat Konsultasi</a>
                </div>
            </div>

            <p class="text-center mt-3 mb-0">
                <a href="<?php echo e(route('perfumes.index')); ?>" class="text-white-50 small text-decoration-none">&larr; Kembali ke Dashboard</a>
            </p>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/premium/status.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Data User'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1 class="page-title">Kelola Data User (Customer)</h1>
        <p class="page-sub">Akun admin tidak ditampilkan di daftar ini.</p>
    </div>

    <div class="toolbar">
        <form action="<?php echo e(route('admin.users.index')); ?>" method="GET" class="search" role="search">
            <label for="q" class="sr-only">Cari user</label>
            <input id="q" type="search" name="q" value="<?php echo e($q); ?>" placeholder="Cari nama, email, atau username...">
            <button type="submit" class="btn btn-ghost">Cari</button>
            <?php if($q !== ''): ?>
                <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-ghost">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <section class="panel">
        <?php if($users->isEmpty()): ?>
            <div class="empty">
                <?php if($q !== ''): ?>
                    <strong>Tidak ada user yang cocok</strong>
                    Coba kata kunci lain.
                <?php else: ?>
                    <strong>Belum ada user terdaftar</strong>
                    Akun customer akan muncul di sini setelah mereka registrasi.
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="col-no">No</th>
                            <th>Nama Lengkap</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>Status</th>
                            <th class="col-act">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $active = $user->subscriptions->first(); ?>
                            <tr>
                                <td class="col-no"><?php echo e($users->firstItem() + $loop->index); ?></td>
                                <td data-label="Nama Lengkap" class="strong"><?php echo e($user->name); ?></td>
                                <td data-label="Email" style="overflow-wrap: anywhere;"><?php echo e($user->email); ?></td>
                                <td data-label="Username"><?php echo e($user->username); ?></td>
                                <td data-label="Status">
                                    <?php if($active): ?>
                                        <span class="badge badge--pro">Premium s/d <?php echo e($active->ends_at->locale('id')->translatedFormat('j M Y')); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge--free">Gratis</span>
                                    <?php endif; ?>
                                </td>
                                <td class="col-act">
                                    <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST"
                                          data-confirm="Akun &quot;<?php echo e($user->name); ?>&quot; akan dihapus permanen beserta ulasan, langganan, dan riwayat chat-nya."
                                          data-confirm-title="Hapus user?">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php echo e($users->links('admin.partials.pagination')); ?>

        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/admin/users/index.blade.php ENDPATH**/ ?>
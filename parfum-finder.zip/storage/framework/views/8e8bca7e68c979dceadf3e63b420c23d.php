<?php if($paginator->hasPages()): ?>
    <nav class="pager" aria-label="Halaman">
        <span class="pager-info">Menampilkan <?php echo e($paginator->firstItem()); ?>-<?php echo e($paginator->lastItem()); ?> dari <?php echo e($paginator->total()); ?></span>

        <div class="pager-actions">
            <?php if($paginator->onFirstPage()): ?>
                <span class="btn btn-ghost is-disabled" aria-disabled="true">Sebelumnya</span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="btn btn-ghost">Sebelumnya</a>
            <?php endif; ?>

            <span class="pager-now">Halaman <?php echo e($paginator->currentPage()); ?> dari <?php echo e($paginator->lastPage()); ?></span>

            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="btn btn-ghost">Berikutnya</a>
            <?php else: ?>
                <span class="btn btn-ghost is-disabled" aria-disabled="true">Berikutnya</span>
            <?php endif; ?>
        </div>
    </nav>
<?php endif; ?>
<?php /**PATH D:\laragon\www\parfum-finder\resources\views/admin/partials/pagination.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', $perfume->name . ' - Parfum Finder'); ?>

<?php $__env->startSection('content'); ?>
    
    <section class="bg-black text-center px-3 py-4">
        <h1 class="fw-bold fs-3 m-0"><?php echo e($perfume->name); ?></h1>
    </section>

    <section class="px-3 py-4">
        <div class="container" style="max-width: 56rem;">

            
            <?php if(session('success')): ?>
                <div role="alert" class="alert alert-success small"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            
            <?php if(session('warning')): ?>
                <div role="alert" class="alert alert-warning small"><?php echo e(session('warning')); ?></div>
            <?php endif; ?>

            
            <div class="row g-3">
                
                <div class="col-12 col-md-3">
                    <div class="pf-img-h rounded-3" style="height: 13rem;">
                        
                        <img src="<?php echo e(asset($perfume->image)); ?>" alt="<?php echo e($perfume->name); ?>"
                             onerror="this.style.display='none'">
                    </div>
                </div>

                
                <div class="col-12 col-md-6">
                    <div class="bg-pf-card rounded-3 p-3 h-100">
                        <h2 class="fs-6 fw-bold text-pf-red">Aroma</h2>
                        
                        <?php if($perfume->top_notes): ?>
                            <p class="pf-xs mb-2"><span class="fw-semibold">Top Notes:</span> <?php echo e($perfume->top_notes); ?></p>
                        <?php endif; ?>
                        <?php if($perfume->middle_notes): ?>
                            <p class="pf-xs mb-2"><span class="fw-semibold">Middle Notes:</span> <?php echo e($perfume->middle_notes); ?></p>
                        <?php endif; ?>
                        <?php if($perfume->base_notes): ?>
                            <p class="pf-xs mb-0"><span class="fw-semibold">Bottom Notes:</span> <?php echo e($perfume->base_notes); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="col-12 col-md-3">
                    <div class="bg-pf-card rounded-3 p-3 h-100">
                        <h2 class="fs-6 fw-bold text-pf-red">Informasi</h2>
                        <p class="pf-xs mb-1"><span class="fw-semibold">Kategori:</span> <?php echo e($perfume->category); ?></p>
                        <p class="pf-xs mb-0">
                            <span class="fw-semibold">Harga:</span>
                            
                            <?php if($perfume->price > 0): ?>
                                Rp <?php echo e(number_format($perfume->price, 0, ',', '.')); ?>

                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>

            
            <div class="row g-3 mt-0">
                
                <div class="col-12 col-md-6">
                    <div class="bg-pf-card rounded-3 p-3 h-100">
                        <h2 class="fs-6 fw-bold text-pf-red">Deskripsi</h2>
                        <p class="pf-xs mb-0" style="line-height: 1.6;"><?php echo e($perfume->description ?: 'Deskripsi belum tersedia.'); ?></p>
                    </div>
                </div>

                
                <div class="col-12 col-md-6">
                    
                    <?php if($canViewReviews): ?>
                        <div class="d-flex flex-column gap-3">

                            
                            <?php if($canWriteReview): ?>
                                <div class="bg-pf-card rounded-3 p-3">
                                    <h2 class="fs-6 fw-bold text-pf-red">Tulis Ulasan</h2>

                                    <form action="<?php echo e(route('reviews.store', $perfume)); ?>" method="POST" novalidate>
                                        
                                        <?php echo csrf_field(); ?>

                                        
                                        <div class="mb-2">
                                            <div class="pf-stars" role="radiogroup" aria-label="Rating bintang">
                                                <?php for($i = 5; $i >= 1; $i--): ?>
                                                    <input type="radio" name="rating" id="star-<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                           <?php if((int) old('rating') === $i): echo 'checked'; endif; ?>>
                                                    <label for="star-<?php echo e($i); ?>" title="<?php echo e($i); ?> bintang">
                                                        <span class="visually-hidden"><?php echo e($i); ?> bintang</span>★
                                                    </label>
                                                <?php endfor; ?>
                                            </div>
                                            
                                            <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="pf-error"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        
                                        <label for="review-body" class="visually-hidden">Ulasan</label>
                                        <textarea id="review-body" name="body" rows="3" maxlength="1000"
                                                  placeholder="Tulis pengalaman kamu..."
                                                  class="form-control pf-xs mb-2"><?php echo e(old('body')); ?></textarea>
                                        
                                        <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="pf-error mb-2"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        <button type="submit" class="btn btn-pf-red btn-sm rounded-pill px-3 pf-xs fw-semibold">Kirim</button>
                                    </form>
                                </div>
                            <?php endif; ?>

                            
                            <div class="bg-pf-card rounded-3 p-3">
                                <h2 class="fs-6 fw-bold text-pf-red">Ulasan Premium</h2>

                                
                                <?php if($reviews->isNotEmpty()): ?>
                                    <p class="text-white-50 mb-2" style="font-size: .7rem;">
                                        <span class="text-warning">★</span> <?php echo e(number_format($average, 1)); ?> dari 5
                                        &middot; <?php echo e($reviews->count()); ?> ulasan
                                    </p>
                                <?php endif; ?>

                                <div class="pf-review-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        
                                        <div class="pb-2 mb-2 <?php echo e($loop->last ? '' : 'border-bottom border-secondary'); ?>">
                                            <div class="small fw-bold">
                                                <?php echo e($review->user?->username ?? $review->user?->name); ?>

                                                
                                                <?php if($review->user_id === auth()->id()): ?>
                                                    <span class="badge text-bg-secondary fw-normal">Kamu</span>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <div class="text-white-50" style="font-size: .65rem;">
                                                <?php echo e($review->created_at->locale('id')->translatedFormat('j M Y H:i')); ?>

                                            </div>
                                            
                                            <div class="my-1" style="line-height: 1;" role="img" aria-label="Rating <?php echo e($review->rating); ?> dari 5">
                                                <?php for($i = 1; $i <= 5; $i++): ?>
                                                    <span class="<?php echo e($i <= $review->rating ? 'text-warning' : 'text-secondary'); ?>">★</span>
                                                <?php endfor; ?>
                                            </div>
                                            
                                            <div class="pf-xs"><?php echo nl2br(e($review->body)); ?></div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        
                                        <p class="pf-xs text-white-50 m-0">
                                            Belum ada ulasan untuk parfum ini.
                                            <?php if($canWriteReview): ?> Jadilah yang pertama! <?php endif; ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        
                        <div class="bg-pf-card rounded-3 p-3 h-100">
                            <h2 class="pf-xs fw-bold">🔒 Ulasan hanya untuk Premium</h2>
                            <?php if(auth()->guard()->guest()): ?>
                                
                                <a href="<?php echo e(route('login')); ?>" class="btn btn-pf btn-sm rounded-pill pf-xs fw-semibold mt-2">Login</a>
                            <?php else: ?>
                                
                                <a href="<?php echo e(route('premium')); ?>" class="btn btn-pf btn-sm rounded-pill pf-xs fw-semibold mt-2">Upgrade Premium</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="d-flex justify-content-end mt-3">
                <a href="<?php echo e(auth()->check() ? route('perfumes.index') : url('/')); ?>" class="btn btn-pf-red btn-sm rounded-pill pf-xs fw-semibold px-3">&larr; Kembali</a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/perfume-detail.blade.php ENDPATH**/ ?>
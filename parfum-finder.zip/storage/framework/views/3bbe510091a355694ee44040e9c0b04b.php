<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1 class="page-title">Dashboard Admin</h1>
        <p class="page-sub">Ringkasan Sistem Parfum Finder</p>
    </div>

    <div class="menu-grid">
        <a href="<?php echo e(route('admin.perfumes.index')); ?>" class="menu-card">
            <h2>Data Parfum</h2>
            <p>Menu untuk manajemen parfum</p>
            <span class="stat"><?php echo e($perfumeCount); ?> parfum</span>
        </a>

        <a href="<?php echo e(route('admin.users.index')); ?>" class="menu-card">
            <h2>Data User</h2>
            <p>Menu untuk manajemen akun</p>
            <span class="stat"><?php echo e($userCount); ?> user</span>
        </a>

        <a href="<?php echo e(route('admin.premium.index')); ?>" class="menu-card">
            <h2>Member Premium</h2>
            <p>Riwayat langganan, masa aktif, dan harga</p>
            <span class="stat"><?php echo e($premiumCount); ?> member aktif</span>
        </a>

        <a href="<?php echo e(route('admin.chats.index')); ?>" class="menu-card">
            <h2>Chat Konsultasi</h2>
            <p>Menu untuk chat konsultasi dengan customer</p>
            <?php if($pendingChats > 0): ?>
                <span class="stat stat--alert"><?php echo e($pendingChats); ?> perlu dibalas</span>
            <?php else: ?>
                <span class="stat">Semua sudah dibalas</span>
            <?php endif; ?>
        </a>
    </div>

    <section class="info">
        <h2>Informasi</h2>
        <p>Gunakan menu di samping untuk mengelola data parfum, akun user, dan chat konsultasi member Premium.</p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
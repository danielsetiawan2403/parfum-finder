<?php $__env->startSection('title', 'Chat Konsultasi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1 class="page-title">Chat Konsultasi Admin</h1>
        <p class="page-sub">Pilih nama user untuk membuka room chat. Percakapan yang belum dibalas tampil paling atas.</p>
    </div>

    <?php if($users->isEmpty()): ?>
        <section class="panel">
            <div class="empty">
                <strong>Belum ada pesan masuk</strong>
                Pesan dari member Premium akan muncul di sini.
            </div>
        </section>
    <?php else: ?>
        <section class="panel chat-users">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('admin.chats.show', $user)); ?>" class="chat-user <?php echo e($user->unread_count > 0 ? 'is-pending' : ''); ?>">
                    <span class="chat-avatar" aria-hidden="true"><?php echo e(mb_strtoupper(mb_substr($user->name, 0, 1))); ?></span>

                    <span class="chat-user-info">
                        <strong><?php echo e($user->name); ?></strong>
                        <small><?php echo e($user->username); ?> &middot; <?php echo e($user->last_message_at->locale('id')->translatedFormat('j M, H:i')); ?></small>
                    </span>

                    <?php if($user->unread_count > 0): ?>
                        <span class="badge badge--warn"><?php echo e($user->unread_count); ?> pesan baru</span>
                    <?php else: ?>
                        <span class="badge badge--ok">Sudah dibalas</span>
                    <?php endif; ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\parfum-finder\resources\views/admin/chats/index.blade.php ENDPATH**/ ?>